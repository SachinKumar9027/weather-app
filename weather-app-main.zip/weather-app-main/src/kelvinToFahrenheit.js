export default function kelvinToFahrenheit(K) {
  return (K - 273.15) * (9/5) + 32
}
